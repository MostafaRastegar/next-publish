export const logger = (x: string) => console.log(x);
